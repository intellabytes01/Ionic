export class SideMenu {
  title: string;
  url: string;
  icon: string;
}


