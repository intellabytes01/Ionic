import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pr-new-order-button',
  templateUrl: './new-order-button.component.html',
  styleUrls: ['./new-order-button.component.scss'],
})
export class NewOrderButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
