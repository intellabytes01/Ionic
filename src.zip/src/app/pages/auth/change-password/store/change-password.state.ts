export interface OtpState {
    sendOtp: [];
    verifyOtp: [];
    errorMessage: string | null;
  }
