import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pr-retailer',
  templateUrl: './retailer.page.html',
  styleUrls: ['./retailer.page.scss'],
})
export class RetailerPage implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
