export interface IProfileInterface {
    firstName: string;
    retailerId: string;
    email: string;
    mobileNumber: string;
    telephone: string;
    address1: string;
    pincode: string;
    regionId: string;
    licenseNumber: string;
    gstinNumber: string;
    retailerName: string;
    lastName: string;
    gstinOption: string;
    cstNumber: string;
  }
