import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pr-status-distributor',
  templateUrl: './status-distributor.page.html',
  styleUrls: ['./status-distributor.page.scss'],
})
export class StatusDistributorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
