import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pr-request-distributor',
  templateUrl: './request-distributor.page.html',
  styleUrls: ['./request-distributor.page.scss'],
})
export class RequestDistributorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
