export interface Page {
  name: string;
  link: string;
  icon: string;
  disable: boolean;
}
