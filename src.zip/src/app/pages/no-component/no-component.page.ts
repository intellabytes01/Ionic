import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pr-no-component',
  templateUrl: './no-component.page.html',
  styleUrls: ['./no-component.page.scss'],
})
export class NoComponentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
